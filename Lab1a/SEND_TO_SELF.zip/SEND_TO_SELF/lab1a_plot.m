dt = 5e-3;
f = 0.9;
T = 0.005;
A = (1-f)/T;
Kp = 100;
Kd = 0.5;
Kp_2 = 200;
Kd_2 = 0.5;

figure(1);
clf;
subplot(311);
plot(my_data1.time, my_data1.signals.values(:,1))
hold on
plot(my_data1.time, my_data1.signals.values(:,2))


subplot(312);
plot(my_data1.time, my_data1.signals.values(:,5))
hold on
plot(my_data1.time, my_data1.signals.values(:,6))